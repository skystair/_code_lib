/*****************************************************************************
* | File      	:	touch.c
* | Author      :   Waveshare team
* | Function    :   Touch API
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2019-04-30
* | Info        :
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documnetation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to  whom the Software is
# furished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS OR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
******************************************************************************/
#include "touch.h"
#include "LCD_Driver.h"
#include "xpt2046.h"
#include <stdlib.h>
#include <math.h>
#include "system.h"
#include<pic.h>

static tp_dev_t s_tTouch;

/******************************************************************************
function :	initial touch lcd
parameter:
  phwXpos: ponit to x axis
  phwYpos: ponit to y axis
******************************************************************************/
void tp_init(void)
{
	xpt2046_init();
}

/******************************************************************************
function :	draw a touch point on lcd 
parameter:
  phwXpos: x axis
  phwYpos: y axis
  hwColor: point color
******************************************************************************/
void tp_draw_touch_point(uint16_t hwXpos, uint16_t hwYpos, uint16_t hwColor)
{
	lcd_draw_line(hwXpos - 12, hwYpos, hwXpos + 13, hwYpos, hwColor);
	lcd_draw_line(hwXpos, hwYpos - 12, hwXpos, hwYpos + 13, hwColor);
	lcd_draw_dot(hwXpos + 1, hwYpos + 1, hwColor);
	lcd_draw_dot(hwXpos - 1, hwYpos + 1, hwColor);
	lcd_draw_dot(hwXpos + 1, hwYpos - 1, hwColor);
	lcd_draw_dot(hwXpos - 1, hwYpos - 1, hwColor);
	lcd_draw_circle(hwXpos, hwYpos, 6, hwColor);
}

/******************************************************************************
function :	draw a big touch point on lcd 
parameter:
  phwXpos: x axis
  phwYpos: y axis
  hwColor: point color
******************************************************************************/
void tp_draw_big_point(uint16_t hwXpos, uint16_t hwYpos, uint16_t hwColor)
{
	lcd_draw_dot(hwXpos, hwYpos, hwColor);
	lcd_draw_dot(hwXpos + 1, hwYpos, hwColor);
	lcd_draw_dot(hwXpos, hwYpos + 1, hwColor);
	lcd_draw_dot(hwXpos + 1, hwYpos + 1, hwColor);
}

/******************************************************************************
	function :	scan touch
	parameter:
  chCoordType:
******************************************************************************/
uint8_t tp_scan(uint8_t chCoordType)
{
	if (!RA0) {
		if (chCoordType) {
			xpt2046_twice_read_xy(&s_tTouch.hwXpos, &s_tTouch.hwYpos);
		} else if (xpt2046_twice_read_xy(&s_tTouch.hwXpos, &s_tTouch.hwYpos)) {
			s_tTouch.hwXpos = s_tTouch.fXfac * s_tTouch.hwXpos + s_tTouch.iXoff;
			s_tTouch.hwYpos = s_tTouch.fYfac * s_tTouch.hwYpos + s_tTouch.iYoff;
		}
		if (0 == (s_tTouch.chStatus & TP_PRESS_DOWN)) {
			s_tTouch.chStatus = TP_PRESS_DOWN | TP_PRESSED;
			s_tTouch.hwXpos0 = s_tTouch.hwXpos;
			s_tTouch.hwYpos0 = s_tTouch.hwYpos;
		}
	} else {
		if (s_tTouch.chStatus & TP_PRESS_DOWN) {
			s_tTouch.chStatus &= ~(1 << 7);
		} else {
			s_tTouch.hwXpos0 = 0;
			s_tTouch.hwYpos0 = 0;
			s_tTouch.hwXpos = 0xffff;
			s_tTouch.hwYpos = 0xffff;
		}
	}
	return (s_tTouch.chStatus & TP_PRESS_DOWN);
}

void tp_adjust(void)
{
	uint8_t  cnt = 0;
	uint16_t pos_temp[4][2];
	tp_draw_touch_point(20,20,RED);
	while(1){
		tp_scan(1);
		if((s_tTouch.chStatus & 0xC0) == TP_PRESSED){
			s_tTouch.chStatus &= ~(1 << 6);
			
			pos_temp[cnt][0] = s_tTouch.hwXpos;
			pos_temp[cnt][1] = s_tTouch.hwYpos;
			cnt ++;
			switch(cnt) {			   
				case 1:						 
					tp_draw_touch_point(20, 20, WHITE);
					tp_draw_touch_point(LCD_WIDTH - 20, 20, RED);
					break;
				case 2:
					tp_draw_touch_point(LCD_WIDTH - 20, 20, WHITE);
					tp_draw_touch_point(20, LCD_HEIGHT - 20, RED);
					break;
				case 3:
					tp_draw_touch_point(20, LCD_HEIGHT - 20, WHITE);
					tp_draw_touch_point(LCD_WIDTH - 20, LCD_HEIGHT - 20, RED);
					break;
				case 4:
					s_tTouch.fXfac = (float)(LCD_WIDTH - 40) / (int16_t)(pos_temp[1][0] - pos_temp[0][0]);	
					s_tTouch.iXoff = (LCD_WIDTH - s_tTouch.fXfac * (pos_temp[1][0] + pos_temp[0][0])) / 2;

					s_tTouch.fYfac = (float)(LCD_HEIGHT - 40) / (int16_t)(pos_temp[2][1] - pos_temp[0][1]);	  
					s_tTouch.iYoff = (LCD_HEIGHT - s_tTouch.fYfac * (pos_temp[2][1] + pos_temp[0][1])) / 2;
					lcd_clear_screen(WHITE);
					return ;
			}
		}
	}
}

void tp_draw_board(void)
{
	tp_scan(0);
	if (s_tTouch.chStatus & TP_PRESS_DOWN) {
		if (s_tTouch.hwXpos < LCD_WIDTH && s_tTouch.hwYpos < LCD_HEIGHT) {
			tp_draw_big_point(s_tTouch.hwXpos, s_tTouch.hwYpos, RED);
		}
	}
}

