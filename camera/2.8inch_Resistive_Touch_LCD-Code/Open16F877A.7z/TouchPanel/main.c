
#include "clk.h"
 __CONFIG(0xFF32);


#include "LCD_Driver.h"
#include "touch.h"
#include "xpt2046.h"
void main(void)
{
    lcd_init();	
	tp_init();
    tp_adjust();
    while(1){
        tp_draw_board();
    }
}
