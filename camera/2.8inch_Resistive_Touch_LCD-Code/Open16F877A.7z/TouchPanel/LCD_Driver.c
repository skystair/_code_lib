/*****************************************************************************
* | File      	:		LCD_Driver.c
* | Author      :   Waveshare team
* | Function    :   LCD Driver
* | Info        :
*----------------
* |	This version:   V1.2
* | Date        :   2019-08-16
* | Info        :
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documnetation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to  whom the Software is
# furished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS OR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
******************************************************************************/

#include "LCD_Driver.h"
#include <stdlib.h>
#include "system.h"

/******************************************************************************
function :	initial SPI1
parameter:
******************************************************************************/
void spi_init(void)
{
    TRISC = 0x10;
	SSPSTAT = 0X80;
	SSPCON=0X30;
	INTCON=0X00;
	PIR1=0X00;
}

/******************************************************************************
function :	SPI1 send data
parameter:
send_char:	sned data
******************************************************************************/
uint8_t spi1_communication(uint8_t send_char)
{
    SSPBUF=(u8)(send_char);
	while(!SSPIF);
	SSPIF=0;
	return 0;
}

/******************************************************************************
function :	write eight bits' data to LCD
parameter:
  chByte : send data
  chCmd  : command or data
******************************************************************************/
void lcd_write_byte(uint8_t chByte, uint8_t chCmd)
{
    if (chCmd) {
        LCD_DC_H();
    } else {
        LCD_DC_L();
    }
    LCD_CS_L();
    spi1_communication(chByte);
    LCD_CS_H();
}

/******************************************************************************
function :	write sixteen bits' data to LCD
parameter:
  chByte : send data
  chCmd  : command or data
******************************************************************************/
void lcd_write_word(uint16_t hwData)
{
    LCD_DC_H();
    LCD_CS_L();
    spi1_communication(hwData >> 8);
    spi1_communication(hwData & 0xFF);
    LCD_CS_H();
}

/******************************************************************************
function :	write data to LCD register
parameter:
     chByte : send data
		 chCmd  : command or data
******************************************************************************/
void lcd_write_command(uint8_t chRegister, uint8_t chValue)
{
	lcd_write_byte(chRegister, LCD_CMD);
	lcd_write_byte(chValue, LCD_DATA);
}

/********************************************************************************
Function Name  : initials lcd control pin 
			parameter:
********************************************************************************/
void lcd_ctrl_port_init(void)
{
	ADCON1 = 0x06;
	TRISA=0x01;
    TRISD=0x00;
    TRISC0=0;
    TRISC1=0;
    TRISC2=0;
}

/******************************************************************************
Function Name  : initials lcd control pin 
			parameter:
******************************************************************************/
void lcd_init(void)
{
	lcd_ctrl_port_init();
  	spi_init();
	
	LCD_RST_H();
	delay_ms(5);
	LCD_RST_L();
	delay_ms(5);
	LCD_RST_H();
	delay_ms(5);
	LCD_CS_H();
#ifdef HX8347D_DEVICE
	lcd_write_command(0xEA,0x00);
	lcd_write_command(0xEB,0x20);
	lcd_write_command(0xEC,0x0C);
	lcd_write_command(0xED,0xC4);
	lcd_write_command(0xE8,0x38);
	lcd_write_command(0xE9,0x10);
	lcd_write_command(0xF1,0x01);
	lcd_write_command(0xF2,0x10);
	lcd_write_command(0x40,0x01); 
	lcd_write_command(0x41,0x00); 
	lcd_write_command(0x42,0x00); 
	lcd_write_command(0x43,0x10); 
	lcd_write_command(0x44,0x0E); 
	lcd_write_command(0x45,0x24); 
	lcd_write_command(0x46,0x04); 
	lcd_write_command(0x47,0x50); 
	lcd_write_command(0x48,0x02); 
	lcd_write_command(0x49,0x13); 
	lcd_write_command(0x4A,0x19); 
	lcd_write_command(0x4B,0x19); 
	lcd_write_command(0x4C,0x16); 
	lcd_write_command(0x50,0x1B); 
	lcd_write_command(0x51,0x31); 
	lcd_write_command(0x52,0x2F); 
	lcd_write_command(0x53,0x3F); 
	lcd_write_command(0x54,0x3F); 
	lcd_write_command(0x55,0x3E); 
	lcd_write_command(0x56,0x2F); 
	lcd_write_command(0x57,0x7B); 
	lcd_write_command(0x58,0x09); 
	lcd_write_command(0x59,0x06); 
	lcd_write_command(0x5A,0x06); 
	lcd_write_command(0x5B,0x0C); 
	lcd_write_command(0x5C,0x1D); 
	lcd_write_command(0x5D,0xCC); 
	lcd_write_command(0x1B,0x1B);
	lcd_write_command(0x1A,0x01);
	lcd_write_command(0x24,0x2F);
	lcd_write_command(0x25,0x57);
	lcd_write_command(0x23,0x88);
	lcd_write_command(0x18,0x34);
	lcd_write_command(0x19,0x01);
	lcd_write_command(0x01,0x00);
	lcd_write_command(0x1F,0x88);
	lcd_write_command(0x1F,0x80);
	lcd_write_command(0x1F,0x90);
	lcd_write_command(0x1F,0xD0);
	lcd_write_command(0x17,0x05); 
	lcd_write_command(0x36,0x02); 
	lcd_write_command(0x28,0x38);
	lcd_write_command(0x28,0x3F);
	lcd_write_command(0x16,0x18); 
	lcd_write_command(0x02,0x00);
	lcd_write_command(0x03,0x00);
	lcd_write_command(0x04,0x00);
	lcd_write_command(0x05,0xEF);
	lcd_write_command(0x06,0x00);
	lcd_write_command(0x07,0x00);
	lcd_write_command(0x08,0x01);
	lcd_write_command(0x09,0x3F);
#elif defined ST7789_DEVICE
	lcd_write_byte(0x11,LCD_CMD);
	delay_ms(10);
	lcd_write_command(0x36,0x00);
	lcd_write_command(0x3a,0x05);
	lcd_write_byte(0xb2,LCD_CMD);
	lcd_write_byte(0x0c,LCD_DATA);
	lcd_write_byte(0x0c,LCD_DATA);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte(0x33,LCD_DATA);
	lcd_write_byte(0x33,LCD_DATA);
	lcd_write_command(0xb7,0x35);
	lcd_write_command(0xbb,0x28);
	lcd_write_command(0xc0,0x3c);
	lcd_write_command(0xc2,0x01);
	lcd_write_command(0xc3,0x0b);
	lcd_write_command(0xc4,0x20);
	lcd_write_command(0xc6,0x0f);
	lcd_write_byte(0xD0,LCD_CMD);
	lcd_write_byte(0xa4,LCD_DATA);
	lcd_write_byte(0xa1,LCD_DATA);
	lcd_write_byte(0xe0,LCD_CMD);
	lcd_write_byte(0xd0,LCD_DATA);
	lcd_write_byte(0x01,LCD_DATA);
	lcd_write_byte(0x08,LCD_DATA);
	lcd_write_byte(0x0f,LCD_DATA);
	lcd_write_byte(0x11,LCD_DATA);
	lcd_write_byte(0x2a,LCD_DATA);
	lcd_write_byte(0x36,LCD_DATA);
	lcd_write_byte(0x55,LCD_DATA);
	lcd_write_byte(0x44,LCD_DATA);
	lcd_write_byte(0x3a,LCD_DATA);
	lcd_write_byte(0x0b,LCD_DATA);
	lcd_write_byte(0x06,LCD_DATA);
	lcd_write_byte(0x11,LCD_DATA);
	lcd_write_byte(0x20,LCD_DATA);
	lcd_write_byte(0xe1,LCD_CMD);
	lcd_write_byte(0xd0,LCD_DATA);
	lcd_write_byte(0x02,LCD_DATA);
	lcd_write_byte(0x07,LCD_DATA);
	lcd_write_byte(0x0a,LCD_DATA);
	lcd_write_byte(0x0b,LCD_DATA);
	lcd_write_byte(0x18,LCD_DATA);
	lcd_write_byte(0x34,LCD_DATA);
	lcd_write_byte(0x43,LCD_DATA);
	lcd_write_byte(0x4a,LCD_DATA);
	lcd_write_byte(0x2b,LCD_DATA);
	lcd_write_byte(0x1b,LCD_DATA);
	lcd_write_byte(0x1c,LCD_DATA);
	lcd_write_byte(0x22,LCD_DATA);
	lcd_write_byte(0x1f,LCD_DATA);
	lcd_write_command(0x55,0xB0);
	lcd_write_byte(0x29,LCD_CMD);
#endif	
	lcd_clear_screen(WHITE);
}

/******************************************************************************
Function Name  : clear lcd screen
			parameter:
				hwColor: background color
******************************************************************************/
void lcd_clear_screen(uint16_t hwColor)
{
	uint32_t i, wCount = LCD_WIDTH;
	wCount *= LCD_HEIGHT;

#ifdef HX8347D_DEVICE	
	lcd_set_cursor(0, 0);
	lcd_write_byte(0x22, LCD_CMD);
	LCD_DC_H();
	LCD_CS_L();
	for (i = 0; i < wCount; i ++) {
		spi1_communication(hwColor >> 8);
		spi1_communication(hwColor & 0xFF);
	}
#elif defined ST7789_DEVICE
	lcd_write_byte(0x2A,LCD_CMD);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte((LCD_WIDTH-1)&0xff,LCD_DATA);
	lcd_write_byte(0x2B,LCD_CMD);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte(((LCD_HEIGHT-1)>>8)&0xff,LCD_DATA);
	lcd_write_byte((LCD_HEIGHT-1)&0xff,LCD_DATA);
	lcd_write_byte(0x2C,LCD_CMD);
	LCD_DC_H();
	LCD_CS_L();
	for (i = 0; i < wCount; i ++) {
		spi1_communication(hwColor >> 8);
		spi1_communication(hwColor & 0xFF);
	}
#endif
	LCD_CS_H();
}

/******************************************************************************
Function Name  : set lcd cursor
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
******************************************************************************/
void lcd_set_cursor(uint16_t hwXpos, uint16_t hwYpos)
{
	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
#ifdef HX8347_DEVICE
	lcd_write_register(0x02, hwXpos >> 8);
	lcd_write_register(0x03, hwXpos & 0xFF); 
	lcd_write_register(0x06, hwYpos >> 8);
	lcd_write_register(0x07, hwYpos & 0xFF); 
#elif defined ST7789_DEVICE
	lcd_write_byte(0x2A,LCD_CMD);
	lcd_write_byte(0x00,LCD_DATA);
	lcd_write_byte(hwXpos&0xff,LCD_DATA);
	lcd_write_byte(0x2B,LCD_CMD);
	lcd_write_byte((hwYpos>>8)&0xff,LCD_DATA);
	lcd_write_byte(hwYpos&0xff,LCD_DATA);	
#endif
}

/******************************************************************************
Function Name  : lcd draw a dot
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
				hwColor:	dot color
******************************************************************************/
void lcd_draw_dot(uint16_t hwXpos, uint16_t hwYpos, uint16_t hwColor)
{
	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	lcd_set_cursor(hwXpos,hwYpos);
#ifdef HX8347_DEVICE
	lcd_write_byte(0x22, LCD_CMD);
#elif defined ST7789_DEVICE
	lcd_write_byte(0x2C, LCD_CMD);
#endif
	lcd_write_word(hwColor);
}

/******************************************************************************
Function Name  : lcd draw a big dot
			parameter:
	  color_front:	dot color
		  	 hwXpos: x axis position
				h wYpos: y axis position
******************************************************************************/
void lcd_draw_bigdot(uint32_t color_front,
                     uint32_t x,uint32_t y )
{
    lcd_draw_dot(color_front,x,y);
    lcd_draw_dot(color_front,x,y+1);
    lcd_draw_dot(color_front,x,y-1);

    lcd_draw_dot(color_front,x+1,y);
    lcd_draw_dot(color_front,x+1,y+1);
    lcd_draw_dot(color_front,x+1,y-1);
    
    lcd_draw_dot(color_front,x-1,y);    
    lcd_draw_dot(color_front,x-1,y+1);
    lcd_draw_dot(color_front,x-1,y-1);
    
}

/******************************************************************************
Function Name  : lcd draw a line
			parameter:
				hwXpos0: x axis start position
				hwYpos0: y axis start position
				hwXpos1: x axis end position
				hwYpos1: y axis end position
				hwColor: line color
******************************************************************************/
void lcd_draw_line(		uint16_t hwXpos0, uint16_t hwYpos0, 
                      uint16_t hwXpos1, uint16_t hwYpos1, 
                      uint16_t hwColor) 
{
	int x = hwXpos1 - hwXpos0;
	int y = hwYpos1 - hwYpos0;
	int dx = abs(x), sx = hwXpos0 < hwXpos1 ? 1 : -1;
	int dy = -abs(y), sy = hwYpos0 < hwYpos1 ? 1 : -1;
	int err = dx + dy, e2;

	if (hwXpos0 >= LCD_WIDTH || hwYpos0 >= LCD_HEIGHT || hwXpos1 >= LCD_WIDTH || hwYpos1 >= LCD_HEIGHT) {
		return;
	}
    
    for (;;){
        lcd_draw_dot(hwXpos0, hwYpos0 , hwColor);
        e2 = 2 * err;
        if (e2 >= dy) {     
            if (hwXpos0 == hwXpos1) break;
            err += dy; hwXpos0 += sx;
        }
        if (e2 <= dx) {
            if (hwYpos0 == hwYpos1) break;
            err += dx; hwYpos0 += sy;
        }
    }
}

/******************************************************************************
Function Name  : lcd draw a circle
			parameter:
				hwXpos: x axis  position
				hwYpos: y axis  position
			 hwRadius: circle radius
				hwColor: cirlce color
******************************************************************************/
void lcd_draw_circle(		uint16_t hwXpos, uint16_t hwYpos, 
                        uint16_t hwRadius,uint16_t hwColor) 
{
	int x = -hwRadius, y = 0, err = 2 - 2 * hwRadius, e2;

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
    do {
        lcd_draw_dot(hwXpos - x, hwYpos + y, hwColor);
        lcd_draw_dot(hwXpos + x, hwYpos + y, hwColor);
        lcd_draw_dot(hwXpos + x, hwYpos - y, hwColor);
        lcd_draw_dot(hwXpos - x, hwYpos - y, hwColor);
        e2 = err;
        if (e2 <= y) {
            err += ++ y * 2 + 1;
            if(-x == y && e2 <= x) e2 = 0;
        }
        if(e2 > x) err += ++ x * 2 + 1;
    } while(x <= 0);
}


/*-------------------------------END OF FILE-------------------------------*/
