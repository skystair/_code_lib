#ifndef _CLK_H
#define _CLK_H
#include <pic.h>

#endif /*clk_h*/