#include "stm32f10x.h"
#include "LCD28/LCD_Driver.h"
#include "User_systick.h"
#include "usart.h"
#include "touch/touch.h"
#include "xpt2046/xpt2046.h"

int main(void)
{
  lcd_init();
	tp_init();
	tp_adjust();
	tp_dialog();
	while (1)
	{		
		tp_draw_board();
	}
}



