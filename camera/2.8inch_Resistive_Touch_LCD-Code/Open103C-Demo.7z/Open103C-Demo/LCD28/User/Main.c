#include "stm32f10x.h"
#include "LCD_Driver.h"
#include "User_systick.h"
#include "usart.h"

int main(void)
{
	uint8_t i;
	lcd_init();
	lcd_display_test();
	lcd_display_string(50,20,(uint8_t *)"www.waveshare.net",FONT_1608,RED);
	for(i = 0;i<7;i++)
		lcd_display_GB2312( i,RED,70+i*16,100);
	lcd_draw_line(80,150,120,180,BLACK);
	lcd_draw_circle(120,210,20,BLUE);
	lcd_draw_rect(100,250,50,50,GREEN);
	lcd_fill_rect(30,220,50,50,RED);
	while(1){
	}
}
