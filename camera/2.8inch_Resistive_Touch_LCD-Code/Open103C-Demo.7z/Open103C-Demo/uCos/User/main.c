#include "stm32f10x.h"
#include "ucos_ii.h"
#include "LedAndKey.h"
#include "LCD28/LCD_Driver.h"
#include "LedAndKey.h"

#define OS_MINI_STACK_SIZE 128
#define TASK_UART_PRIO 5
#define TASK_LCD_PRIO 6

static  OS_STK TaskStartStk[OS_MINI_STACK_SIZE];
static  OS_STK TaskLcdStk[OS_MINI_STACK_SIZE];

void RCC_Config(void)
{
	ErrorStatus HSEStartUpStatus;
	
	RCC_DeInit();
	RCC_HSEConfig(RCC_HSE_ON);
	HSEStartUpStatus = RCC_WaitForHSEStartUp();
	if(HSEStartUpStatus == SUCCESS){
		RCC_HCLKConfig(RCC_SYSCLK_Div1);
		RCC_PCLK2Config(RCC_HCLK_Div1); 
		RCC_PCLK1Config(RCC_HCLK_Div2);
		FLASH_SetLatency(FLASH_Latency_2);
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
		RCC_PLLCmd(ENABLE);
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET);
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
		while(RCC_GetSYSCLKSource() != 0x08); 
	}
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
}

static void TaskUart(void* p_arg)
{
   
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB , ENABLE);
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	LedGpioConfiguration();

	while(1){
		GPIO_WriteBit( IO_LED_ARRAY, IO_LED1 | IO_LED2 | IO_LED3 | IO_LED4,Bit_SET);
		OSTimeDly(50);
		GPIO_WriteBit( IO_LED_ARRAY, IO_LED1 | IO_LED2 | IO_LED3 | IO_LED4,Bit_RESET);
		OSTimeDly(50);
	}
}

static  void TaskLcd(void* p_arg)
{
	uint8_t i;
	lcd_init();
	lcd_clear_screen(WHITE);
	while(1){
		for(i=6;i<15;i++){
			lcd_display_string( 50,i+(i-6)*12,(uint8_t *)"  *www.waveshare.net*  ",FONT_1206, BLACK);
			OSTimeDly(100);
		}
		for(i=5;i<15;i++){
			lcd_display_string( 35,128+i+(i-6)*12,(uint8_t *)"  *****UCOS TEST*****  ",FONT_1608, RED);
			OSTimeDly(100);
		}
	}
}

int main(void)
{     
	RCC_Config();

	SysTick_Config((uint32_t)9000);
	SysTick_CLKSourceConfig(SysTick_CLKSource_HCLK_Div8);
	OSInit();
  OSTaskCreate((void (*) (void *)) TaskUart,
               (void *) 0,
               (OS_STK *) &TaskStartStk[OS_MINI_STACK_SIZE - 1],
               (INT8U) TASK_UART_PRIO);

   OSTaskCreate((void (*) (void *)) TaskLcd,
               (void *) 0,
               (OS_STK *) &TaskLcdStk[OS_MINI_STACK_SIZE - 1],
               (INT8U) TASK_LCD_PRIO);

	OSTimeSet(0);
	OSStart(); 

	return (0);
}



//ϵͳ���ӣ���������
#if (OS_APP_HOOKS_EN > 0)
void App_TaskCreateHook(OS_TCB* ptcb)
{
}

void App_TaskDelHook(OS_TCB* ptcb)
{
   (void) ptcb;
}

void App_TaskIdleHook(void)
{
}

void App_TaskStatHook(void)
{
}

#if OS_TASK_SW_HOOK_EN > 0
void App_TaskSwHook(void)
{
}
#endif

void App_TCBInitHook(OS_TCB* ptcb)
{
   (void) ptcb;
}

#endif
