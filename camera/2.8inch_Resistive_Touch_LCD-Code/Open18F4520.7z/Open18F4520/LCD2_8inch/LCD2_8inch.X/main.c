/* 
 * File:   main.c
 * Author: wave share
 *
 * Created on August 26, 2019, 11:10 AM
 */

#include <stdio.h>
#include <stdlib.h>
#include <htc.h>
#include "LCD_Driver.h"
#include "LCD_lib.h"
#include "xpt2046.h"
#include "touch.h"

// PIC18F4520 Configuration Bit Settings
// 'C' source line config statements
#include <htc.h>
#pragma config CONFIG1H = 0x6
#pragma config CONFIG2L = 0x1F
#pragma config CONFIG2H = 0x1E
#pragma config CONFIG3H = 0x81
#pragma config CONFIG4L = 0x85
#pragma config CONFIG5L = 0xF
#pragma config CONFIG5H = 0xC0
#pragma config CONFIG6L = 0xF
#pragma config CONFIG6H = 0xE0
#pragma config CONFIG7L = 0xF
#pragma config CONFIG7H = 0x40
/*
 * 
 */
int main(int argc, char** argv) {
    unsigned char i;
    lcd_init();	
    tp_init();
	lcd_display_string(60,100,"www.waveshare.net",FONT_1608,RED);
	for(i=0;i<7;i++){
		lcd_display_GB2312(i,RED,70+i*16,30);
	}
	lcd_draw_line(80,150,120,180,BLACK);
	lcd_draw_circle(120,210,20,BLUE);
	lcd_draw_rect(100,250,50,50,GREEN);
	lcd_fill_rect(30,220,50,50,RED);
    tp_adjust();
    while(1){
    	tp_draw_board();
    }
    return (EXIT_SUCCESS);
}

