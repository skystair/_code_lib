#ifndef _CLK_H
#define _CLK_H



#endif /*clk_h*/