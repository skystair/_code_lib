/*
 * LCD28_Touch.c
 *
 * Created: 2019/5/13 11:40:16
 * Author : 
 */ 
 
#include <avr/io.h>
#include "SPI0.h"
#include "hx8347d.h"
#include "LCD_lib.h"
#include <util/delay.h>

int main(void)
{
	/* Replace with your application code */
	DDRA=0XFF;
	PORTA=0X00;
	DDRD=0X40;

	lcd_init();
	_delay_ms(10);
	lcd_display_test();

	while(1);
}

