/*****************************************************************************
* | File      	:	hx8347d.c
* | Author      :   Waveshare team
* | Function    :   HXD8347D driver
* | Info        :
*----------------
* |	This version:   V1.0
* | Date        :   2019-04-29
* | Info        :
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documnetation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to  whom the Software is
# furished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in
# all copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS OR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
# THE SOFTWARE.
#
******************************************************************************/

#include <avr/io.h>
#include <util/delay.h>
#include "SPI0.h"
#include "hx8347d.h"
#include "LCD_lib.h"

/******************************************************************************
function :	initial SPI1
parameter:
******************************************************************************/
void spi1_init(void)
{	DDRB=0xff;
	PORTB=0X00;
	SPCR=0x50;        
	SPSR=0x00;		
}

/******************************************************************************
function :	SPI1 send data
parameter:
send_char:	sned data
******************************************************************************/
uchar spi1_communication(uint8_t send_char)
{
	SPDR = send_char;               
	while (!(SPSR & (1<<SPIF)));    
	return SPDR;
}

/******************************************************************************
function :	write eight bits' data to LCD
parameter:
  chByte : send data
  chCmd  : command or data
******************************************************************************/
void lcd_write_byte(uint8_t chByte, uint8_t chCmd)
{
    if (chCmd) {
        LCD_RS_H();
    } else {
        LCD_RS_L();
    }
    
    LCD_CS_L();
    spi1_communication(chByte);
    LCD_CS_H();
}

/******************************************************************************
function :	write sixteen bits' data to LCD
parameter:
  chByte : send data
  chCmd  : command or data
******************************************************************************/
void lcd_write_word(uint16_t hwData)
{
    LCD_RS_H();
    LCD_CS_L();
    spi1_communication(hwData >> 8);
    spi1_communication(hwData & 0xFF);
    LCD_CS_H();
}

/******************************************************************************
function :	write data to LCD register
parameter:
     chByte : send data
		 chCmd  : command or data
******************************************************************************/
void lcd_write_register(uint8_t chRegister, uint8_t chValue)
{
	lcd_write_byte(chRegister, LCD_CMD);
	lcd_write_byte(chValue, LCD_DATA);
}

/********************************************************************************
Function Name  : initials lcd control pin 
			parameter:
********************************************************************************/
void lcd_ctrl_port_init(void)
{
	DDRD=0XFF;
}

/******************************************************************************
Function Name  : initials lcd control pin 
			parameter:
******************************************************************************/
void lcd_init(void)
{
	lcd_ctrl_port_init();
  	spi1_init();
	
	PORTB &= ~(1<<PB6);
	_delay_us(5);
	PORTB |= (1<<PB6);
	_delay_us(5);
		
	DDRE |= 0x20;
	PORTE &= ~(1<<PE5);
	_delay_us(5);
	PORTE |= (1<<PE5);
	_delay_us(5);

	lcd_write_register(0xEA,0x00);
	lcd_write_register(0xEB,0x20);
	lcd_write_register(0xEC,0x0C);
	lcd_write_register(0xED,0xC4);
	lcd_write_register(0xE8,0x38);
	lcd_write_register(0xE9,0x10);
	lcd_write_register(0xF1,0x01);
	lcd_write_register(0xF2,0x10);
	lcd_write_register(0x40,0x01); 
	lcd_write_register(0x41,0x00); 
	lcd_write_register(0x42,0x00); 
	lcd_write_register(0x43,0x10); 
	lcd_write_register(0x44,0x0E); 
	lcd_write_register(0x45,0x24); 
	lcd_write_register(0x46,0x04); 
	lcd_write_register(0x47,0x50); 
	lcd_write_register(0x48,0x02); 
	lcd_write_register(0x49,0x13); 
	lcd_write_register(0x4A,0x19); 
	lcd_write_register(0x4B,0x19); 
	lcd_write_register(0x4C,0x16); 
	lcd_write_register(0x50,0x1B); 
	lcd_write_register(0x51,0x31); 
	lcd_write_register(0x52,0x2F); 
	lcd_write_register(0x53,0x3F); 
	lcd_write_register(0x54,0x3F); 
	lcd_write_register(0x55,0x3E); 
	lcd_write_register(0x56,0x2F); 
	lcd_write_register(0x57,0x7B); 
	lcd_write_register(0x58,0x09); 
	lcd_write_register(0x59,0x06); 
	lcd_write_register(0x5A,0x06); 
	lcd_write_register(0x5B,0x0C); 
	lcd_write_register(0x5C,0x1D); 
	lcd_write_register(0x5D,0xCC); 
	lcd_write_register(0x1B,0x1B);
	lcd_write_register(0x1A,0x01);
	lcd_write_register(0x24,0x2F);
	lcd_write_register(0x25,0x57);
	lcd_write_register(0x23,0x88);
	lcd_write_register(0x18,0x34);
	lcd_write_register(0x19,0x01);
	lcd_write_register(0x01,0x00);
	lcd_write_register(0x1F,0x88);
	lcd_write_register(0x1F,0x80);
	lcd_write_register(0x1F,0x90);
	lcd_write_register(0x1F,0xD0);
	lcd_write_register(0x17,0x05); 
	lcd_write_register(0x36,0x02); 
	lcd_write_register(0x28,0x38);
	lcd_write_register(0x28,0x3F);
	lcd_write_register(0x16,0x18); 
	lcd_write_register(0x02,0x00);
	lcd_write_register(0x03,0x00);
	lcd_write_register(0x04,0x00);
	lcd_write_register(0x05,0xEF);
	lcd_write_register(0x06,0x00);
	lcd_write_register(0x07,0x00);
	lcd_write_register(0x08,0x01);
	lcd_write_register(0x09,0x3F);
	
	lcd_clear_screen(WHITE);
}

/******************************************************************************
Function Name  : clear lcd screen
			parameter:
				hwColor: background color
******************************************************************************/
void lcd_clear_screen(uint16_t hwColor)
{
	uint32_t i, wCount = LCD_WIDTH;
	wCount *= LCD_HEIGHT;
	
	lcd_set_cursor(0, 0);
	lcd_write_byte(0x22, LCD_CMD);

	LCD_RS_H();
	LCD_CS_L();
	for (i = 0; i < wCount; i ++) {
		spi1_communication(hwColor >> 8);
		spi1_communication(hwColor & 0xFF);
	}
	LCD_CS_H();
}

/******************************************************************************
Function Name  : set lcd cursor
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
******************************************************************************/
void lcd_set_cursor(uint16_t hwXpos, uint16_t hwYpos)
{
	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
  lcd_write_register(0x02, hwXpos >> 8);
	lcd_write_register(0x03, hwXpos & 0xFF); 
	lcd_write_register(0x06, hwYpos >> 8);
	lcd_write_register(0x07, hwYpos & 0xFF); 
}

/******************************************************************************
Function Name  : lcd display char
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
				  chChr: display character
				 chSize: character size
			  hwColor: character color
******************************************************************************/
void lcd_display_char(	 uint16_t hwXpos, 
                         uint16_t hwYpos, 
                         uint8_t chChr,   
                         uint8_t chSize,  
                         uint16_t hwColor)
{      	
	uint8_t i, j, chTemp;
	uint16_t hwYpos0 = hwYpos, hwColorVal = 0;

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}

    for (i = 0; i < chSize; i ++) {
				if (FONT_1206 == chSize) {
					chTemp = c_chFont1206[chChr - 0x20][i];  
				}
				else if (FONT_1608 == chSize) { 
					chTemp = c_chFont1608[chChr - 0x20][i];
				}			
        for (j = 0; j < 8; j ++) {
					if (chTemp & 0x80) {
						hwColorVal = hwColor;
						lcd_draw_dot(hwXpos, hwYpos, hwColorVal);
					}			
					chTemp <<= 1;
					hwYpos ++;
					if ((hwYpos - hwYpos0) == chSize) {
						hwYpos = hwYpos0;
						hwXpos ++;
						break;
					}
				}  	 
    } 
}
/******************************************************************************
Function Name  : lcd display string
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
		  pchString: display string
				 chSize: string size
			  hwColor: string color
******************************************************************************/
void lcd_display_string(	uint16_t hwXpos,uint16_t hwYpos,
													const uint8_t *pchString,
													uint8_t chSize,uint16_t hwColor)
{

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
    while (*pchString != '\0') {       
        if (hwXpos > (LCD_WIDTH - chSize / 2)) {
					hwXpos = 0;
					hwYpos += chSize;
					if (hwYpos > (LCD_HEIGHT - chSize)) {
						hwYpos = hwXpos = 0;
						lcd_clear_screen(0x00);
					}
				}
		
        lcd_display_char(hwXpos, hwYpos, (uint8_t)*pchString, chSize, hwColor);
        hwXpos += chSize / 2;
        pchString ++;
    } 
}

/******************************************************************************
Function Name  : lcd display chinese character
			parameter:
						 gb:	which character in GB2312[][32] 
	  color_front:	character color
				 hwXpos: x axis position
				 hwYpos: y axis position
******************************************************************************/
void lcd_display_GB2312(  uint8_t gb, uint16_t color_front, 
													uint16_t postion_x,uint16_t postion_y )
{
	uint8_t i, j,chTemp;
	uint16_t hwYpos0 = postion_y, hwColorVal = 0;
	
	if (postion_x >= LCD_WIDTH || postion_y >= LCD_HEIGHT) {
		return;
	}
	
	for (i = 0; i < 32; i++) {
		chTemp = GB2312[gb][i];
		for (j = 0; j < 8; j++) {
			if (chTemp & 0x80) {
					hwColorVal = color_front;
				if(i<15)
					lcd_draw_dot(postion_x, postion_y, hwColorVal);
				else
					lcd_draw_dot(postion_x-16, postion_y+8, hwColorVal);
			}
			chTemp <<= 1;
			postion_y ++;
			if ((postion_y - hwYpos0) == 8) {
				postion_y = hwYpos0;
				postion_x ++;
				break;
			}
		}
	}
}

/******************************************************************************
Function Name  : lcd draw a dot
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
				hwColor:	dot color
******************************************************************************/
void lcd_draw_dot(uint16_t hwXpos, uint16_t hwYpos, uint16_t hwColor)
{
	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	lcd_set_cursor(hwXpos, hwYpos);
	lcd_write_byte(0x22, LCD_CMD);
	lcd_write_word(hwColor);

}

/******************************************************************************
Function Name  : lcd draw a big dot
			parameter:
	  color_front:	dot color
		  	 hwXpos: x axis position
				h wYpos: y axis position
******************************************************************************/
void lcd_draw_bigdot(uint32_t color_front,
                     uint32_t x,uint32_t y )
{
    lcd_draw_dot(color_front,x,y);
    lcd_draw_dot(color_front,x,y+1);
    lcd_draw_dot(color_front,x,y-1);

    lcd_draw_dot(color_front,x+1,y);
    lcd_draw_dot(color_front,x+1,y+1);
    lcd_draw_dot(color_front,x+1,y-1);
    
    lcd_draw_dot(color_front,x-1,y);    
    lcd_draw_dot(color_front,x-1,y+1);
    lcd_draw_dot(color_front,x-1,y-1);
    
}

/******************************************************************************
Function Name  : calculate N power
			parameter:
						 m :	valure
					   n :  exponent
******************************************************************************/
static uint32_t _pow(uint8_t m, uint8_t n)
{
	uint32_t result = 1;
	
	while(n --) result *= m;    
	return result;
}

/******************************************************************************
Function Name  : lcd display number
			parameter:
				 hwXpos: x axis position
				 hwYpos: y axis position
				  chNum: number
				  chLen: number length  
				 chSize: number size
				hwColor: number color
******************************************************************************/
void lcd_display_num(			uint16_t hwXpos,  uint16_t hwYpos, 
                          uint32_t chNum,  uint8_t chLen,   
                          uint8_t chSize,  uint16_t hwColor)
{         	
	uint8_t i;
	uint8_t chTemp, chShow = 0;

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
	for(i = 0; i < chLen; i ++) {
		chTemp = (chNum / _pow(10, chLen - i - 1)) % 10;
		if(chShow == 0 && i < (chLen - 1)) {
			if(chTemp == 0) {
				lcd_display_char(hwXpos + (chSize / 2) * i, hwYpos, ' ', chSize, hwColor);
				continue;
			} else {
				chShow = 1;
			}	 
		}
	 	lcd_display_char(hwXpos + (chSize / 2) * i, hwYpos, chTemp + '0', chSize, hwColor); 
	}
} 

/******************************************************************************
Function Name  : lcd draw a line
			parameter:
				hwXpos0: x axis start position
				hwYpos0: y axis start position
				hwXpos1: x axis end position
				hwYpos1: y axis end position
				hwColor: line color
******************************************************************************/
void lcd_draw_line(		uint16_t hwXpos0, uint16_t hwYpos0, 
                      uint16_t hwXpos1, uint16_t hwYpos1, 
                      uint16_t hwColor) 
{
	int x = hwXpos1 - hwXpos0;
	int y = hwYpos1 - hwYpos0;
	int dx = abs(x), sx = hwXpos0 < hwXpos1 ? 1 : -1;
	int dy = -abs(y), sy = hwYpos0 < hwYpos1 ? 1 : -1;
	int err = dx + dy, e2;

	if (hwXpos0 >= LCD_WIDTH || hwYpos0 >= LCD_HEIGHT || hwXpos1 >= LCD_WIDTH || hwYpos1 >= LCD_HEIGHT) {
		return;
	}
    
    for (;;){
        lcd_draw_dot(hwXpos0, hwYpos0 , hwColor);
        e2 = 2 * err;
        if (e2 >= dy) {     
            if (hwXpos0 == hwXpos1) break;
            err += dy; hwXpos0 += sx;
        }
        if (e2 <= dx) {
            if (hwYpos0 == hwYpos1) break;
            err += dx; hwYpos0 += sy;
        }
    }
}

/******************************************************************************
Function Name  : lcd draw a circle
			parameter:
				hwXpos: x axis  position
				hwYpos: y axis  position
			 hwRadius: circle radius
				hwColor: cirlce color
******************************************************************************/
void lcd_draw_circle(		uint16_t hwXpos, uint16_t hwYpos, 
                        uint16_t hwRadius,uint16_t hwColor) 
{
	int x = -hwRadius, y = 0, err = 2 - 2 * hwRadius, e2;

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
    do {
        lcd_draw_dot(hwXpos - x, hwYpos + y, hwColor);
        lcd_draw_dot(hwXpos + x, hwYpos + y, hwColor);
        lcd_draw_dot(hwXpos + x, hwYpos - y, hwColor);
        lcd_draw_dot(hwXpos - x, hwYpos - y, hwColor);
        e2 = err;
        if (e2 <= y) {
            err += ++ y * 2 + 1;
            if(-x == y && e2 <= x) e2 = 0;
        }
        if(e2 > x) err += ++ x * 2 + 1;
    } while(x <= 0);
}

/******************************************************************************
Function Name  :  fill a rectangle on lcd
			parameter:
				 hwXpos: x axis  position
				 hwYpos: y axis  position
			  hwWidth: rectangle width
			 hwHeight: rectangle height
			  hwColor: rectangle color
******************************************************************************/
void lcd_fill_rect(uint16_t hwXpos, 
                   uint16_t hwYpos, uint16_t hwWidth,
                   uint16_t hwHeight,uint16_t hwColor)
{
	uint16_t i, j;

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
	for(i = 0; i < hwHeight; i ++){
		for(j = 0; j < hwWidth; j ++){
			lcd_draw_dot(hwXpos + j, hwYpos + i, hwColor);
		}
	}
}

/******************************************************************************
Function Name  : draw a vertical line at the specified position on lcd
			parameter:
				 hwXpos: x axis  position
				 hwYpos: y axis  position
			 hwHeight: line height
			  hwColor: vertical linc color
******************************************************************************/
void lcd_draw_v_line(		uint16_t hwXpos,uint16_t hwYpos, 
                        uint16_t hwHeight,uint16_t hwColor)  
{	
	uint16_t i, y1 = MIN(hwYpos + hwHeight, LCD_HEIGHT - 1);

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
    for (i = hwYpos; i < y1; i ++) {
        lcd_draw_dot(hwXpos, i, hwColor);
    }
}

/******************************************************************************
Function Name  : draw a horizonal line at the specified position on lcd
			parameter:
				 hwXpos: x axis  position
				 hwYpos: y axis  position
			  hwWidth: line width
			  hwColor: horizonal linc color
******************************************************************************/
void lcd_draw_h_line(		uint16_t hwXpos, uint16_t hwYpos,  
                        uint16_t hwWidth,uint16_t hwColor)
{	
	uint16_t i, x1 = MIN(hwXpos + hwWidth, LCD_WIDTH - 1);

	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}
	
    for (i = hwXpos; i < x1; i ++) {
        lcd_draw_dot(i, hwYpos, hwColor);
    }
}

/******************************************************************************
Function Name  : draw a rectangle on lcd
			parameter:
				 hwXpos: x axis  position
				 hwYpos: y axis  position
			  hwWidth: rectangle width
			 hwHeight: rectangle height
			  hwColor: rectangle color
******************************************************************************/
void lcd_draw_rect(		uint16_t hwXpos,  
                      uint16_t hwYpos,uint16_t hwWidth, 
                      uint16_t hwHeight,uint16_t hwColor) 
{
	if (hwXpos >= LCD_WIDTH || hwYpos >= LCD_HEIGHT) {
		return;
	}

	lcd_draw_h_line(hwXpos, hwYpos, hwWidth, hwColor);
	lcd_draw_h_line(hwXpos, hwYpos + hwHeight, hwWidth, hwColor);
	lcd_draw_v_line(hwXpos, hwYpos, hwHeight, hwColor);
	lcd_draw_v_line(hwXpos + hwWidth, hwYpos, hwHeight + 1, hwColor);
}

/******************************************************************************
Function Name  : clear rectangle on lcd
			parameter:
				 hwXpos: x axis  position
				 hwYpos: y axis  position
			  hwXpos1: rectangle width
			  hwYpos1: rectangle height
	  color_front: rectangle color
******************************************************************************/
void lcd_clear_Rect(	uint32_t color_front, 
											uint32_t hwXpos,uint32_t hwYpos, 
											uint32_t hwXpos1,uint32_t hwYpos1)
{
	uint16_t i, j;

	if (hwXpos1 >= LCD_WIDTH || hwYpos1 >= LCD_HEIGHT) {
		return;
	}
	
	for(i = 0; i < hwYpos1-hwYpos+1; i ++){
		for(j = 0; j < hwXpos1-hwXpos+1; j ++){
			lcd_draw_dot(hwXpos + j, hwYpos + i, color_front);
		}
	}
}

const unsigned int color[] =
{
	0xf800,
	0x07e0,
	0x001f,
	0xffe0,
	0x0000,
	0xffff,
	0x07ff,
	0xf81f
};

/******************************************************************************
Function Name  : test lcd
			parameter:
******************************************************************************/
void lcd_display_test(void)
{
	uint32_t temp, num;
	uint32_t i;
	uint8_t n;

	lcd_clear_screen(RED);
  
	lcd_write_register(0x02, 0 >> 8);
	lcd_write_register(0x03, 0 & 0xFF); 
	lcd_write_register(0x06, 0 >> 8);
	lcd_write_register(0x07, 0 & 0xFF); 
	
	lcd_write_register(0x04, 0xef >> 8);
	lcd_write_register(0x05, 0xef & 0xFF);
	
	lcd_write_register(0x08, 0x013f >> 8);
	lcd_write_register(0x09, 0x013f & 0xFF);
	
	lcd_write_register(0x0A, 0 >> 8);
	lcd_write_register(0x0B, 0 & 0xFF);
	
	lcd_write_register(0x0C, 0  >> 8);
	lcd_write_register(0x0D, 0  & 0xFF);
	lcd_write_byte(0x22, LCD_CMD);
	
	
	LCD_RS_H();
	LCD_CS_L();
	
	for(n=0;n<8;n++){
		LCD_CS_L();
		LCD_RS_H();
		temp=color[n];
		for(num=40*240;num>0;num--)
		{
			lcd_write_word(temp);
		}
	}
	while(1);
	for(n=0;n<8;n++){
		lcd_write_register(0x02, 0 >> 8);
		lcd_write_register(0x03, 0 & 0xFF); 
		lcd_write_register(0x06, 0 >> 8);
		lcd_write_register(0x07, 0 & 0xFF); 
		
		
		lcd_write_register(0x04, 0xef >> 8);
		lcd_write_register(0x05, 0xef & 0xFF);
		
		lcd_write_register(0x08, 0x013f >> 8);
		lcd_write_register(0x09, 0x013f & 0xFF);
		
		lcd_write_register(0x0A, 0 >> 8);
		lcd_write_register(0x0B, 0 & 0xFF);
		
		lcd_write_register(0x0C, 0  >> 8);
		lcd_write_register(0x0D, 0  & 0xFF);
		lcd_write_byte(0x22, LCD_CMD);
		LCD_RS_H();
		LCD_CS_L();
		temp=color[n];
		for(i=0;i<240;i++){
			for(num=0;num<320;num++){
					lcd_write_word(temp);
			}
		}
	}
	LCD_CS_H();
	lcd_clear_screen(GREEN);
}

/*-------------------------------END OF FILE-------------------------------*/
