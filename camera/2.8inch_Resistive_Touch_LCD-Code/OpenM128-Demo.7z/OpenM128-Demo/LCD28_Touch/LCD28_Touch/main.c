/*
 * LCD28_Touch.c
 *
 * Created: 2019/5/13 11:40:16
 * Author : 
 */ 

#include <avr/io.h>
#include "SPI0.h"
#include "hx8347d.h"
#include "LCD_lib.h"
#include <util/delay.h>
#include "touch.h"
#include "xpt2046.h"

int main(void)
{
    /* Replace with your application code */
	lcd_init();
	tp_init();
	tp_adjust();
	tp_dialog();
	while (1)
	{
		tp_draw_board();
	}
}

